# Pattern index

Every pattern gets its own file. Start with [delete detection](cross-cutting/delete-detection.md) and [watermarks](cross-cutting/watermarks.md) — most architectural decisions flow from those two problems. [overview.md](overview.md) explains why there is no single answer.

Status: `draft` (structure only) | `working` (written, not validated against a real environment) | `stable` (validated).

---

## Cross-cutting

| File | Pattern | Status | Notes |
|---|---|---|---|
| `cross-cutting/delete-detection.md` | Delete detection | working | Where deletions are and aren't visible. Soft flag, audit table, or reconciliation. Dimensions can hard-delete; facts usually can't. |
| `cross-cutting/watermarks.md` | Watermark strategy | working | `SinkModifiedOn` mechanics, control table per table, advance only on success. Cascading updates and gaps. |
| `cross-cutting/partition-keys.md` | Partition keys | working | `SinkCreatedMonth` / `SinkCreatedDay` as stored columns derived from `SinkCreatedOn`. Why extraction time and never a business date. |
| `cross-cutting/force-update.md` | `@ForceUpdate` | working | The calling contract every load procedure shares. 0 trusts the change signal, 1 trusts a comparison, 2 trusts nothing. Declared even by procedures that ignore it. |
| `decisions/watermark-is-unreliable.md` | I can't trust `modifiedDateTime` | working | What to rule out before concluding the timestamp is the problem. Usually a wrong column or a missing overlap buffer. |

---

## Bronze — extraction

The question: what change signal does the source provide?

| File | Pattern | Status | Notes |
|---|---|---|---|
| `bronze/full-load.md` | Full load | working | Truncate and reload. Deletes detectable by absence. Cost scales with table size. |
| `bronze/cdc-change-feed.md` | CDC / change feed | working | Source emits insert/update/delete events. Cleanest pattern where available. |
| `bronze/partition-based-incremental.md` | Partition-based incremental | draft | Reload recent partitions by an immutable business date. No delete signal outside the window; needs separate reconciliation. |

---

## Silver — conforming

| File | Pattern | Status | Notes |
|---|---|---|---|
| `silver/full-load.md` | Full load | working | Rebuild from bronze. Use for schema changes and initial loads. Updates the change tracker after load. |
| `silver/incremental-hard-delete.md` | Incremental with hard delete | working | Physically remove deleted rows. Simplifies silver, forces gold reloads. |
| `silver/change-tracking-partitions.md` | Change tracking partitions | working | `silver._ChangeTracker`: `MaxSinkModifiedOn` and `RowCount` per table per partition, so gold doesn't rescan sources. |

---

## Gold — dimensional model

### Dimensions

| File | Pattern | Status | Notes |
|---|---|---|---|
| `gold/dimension-patterns/incremental-load.md` | Dimension incremental load | working | One MERGE. Match on business key + `DataAreaId`, update on watermark, delete what left the source. Surrogate keys from a SEQUENCE via a **default constraint** — `NEXT VALUE FOR` is not allowed inside MERGE. `NOT MATCHED BY SOURCE` must be scoped to the same company as the source or it deletes every other company. |

### Facts

Three patterns, split on one question: **can an existing fact row's values change?**

| File | Pattern | Status | Notes |
|---|---|---|---|
| `gold/fact-patterns/full-load.md` | Full load | working | Truncate and reload. Right more often than it looks — no delete problem, no tracker, nothing to reconcile. Measure amplification before building anything else. |
| `gold/fact-patterns/incremental-date-partition.md` | Date partition rebuild | working | For insert/delete-only facts (posted GL, invoices). Reload whole `SinkCreatedMonth` partitions. Compares tracker watermark **and** row count against `gold._FactLoadState` — the watermark catches arrivals, the row count catches removals. |
| `gold/fact-patterns/incremental-open-settled.md` | Open/settled rebuild | working | For facts whose rows mutate after creation (InventTrans, SalesLine, CustTrans). Rebuild the whole open set each run, freeze settled rows, re-check settled rows whose watermark moved. Driven by a key list, not a partition list. |
| `gold/audit-and-repair.md` | Audit and repair | working | `@ForceUpdate = 1` for facts. Count and sum comparison by partition, rebuild only what disagrees. The only mechanism that catches a row offered to the fact and silently dropped. |

### Anti-pattern

| File | Pattern | Notes |
|---|---|---|
| `gold/no-load-direct-semantic.md` | No-load direct semantic | Skip gold, point Power BI at silver. Two fatal flaws: relationships stuck on string natural keys, and any fact complexity has no escape but a rebuild. |

---

## Snapshots

Before building any of these, check whether the source already keeps date-effective history. F&O does for prices, exchange rates, worker assignments and org hierarchies.

| File | Pattern | Status |
|---|---|---|
| `snapshots/overview.md` | When a snapshot is the right answer | draft |
| `snapshots/period-snapshot.md` | State at regular intervals | draft |
| `snapshots/full-history.md` | Every change appended | draft |

---

## Semantic model

| File | Pattern | Status | Notes |
|---|---|---|---|
| `semantic-model/full-load.md` | Full refresh | working | The default. Simplest and most reliable. |
| `semantic-model/incremental-period-with-deletes.md` | Incremental refresh with deletes | working | Advanced, for very large datasets. Don't partition Power BI by `SinkCreatedOn` — build a metadata layer instead. |

---

## How the choices cascade

1. **Bronze determines silver.** Full versus partition-based extraction decides whether silver can detect a delete at all.
2. **Silver determines gold cost.** Hard delete lets gold hard-delete; soft delete puts a filter in every downstream query forever.
3. **Every pattern either accepts a delete gap or pays to close it.** Know which one you chose before it gets discovered during an audit.

---

## Known gaps

- No DirectQuery or Direct Lake coverage — everything assumes an import semantic model.
- No measured amplification numbers from a real environment.
- Articles link to seven files that were never written: `cross-cutting/hash-comparison.md`, `cross-cutting/layer-strategy-mismatch.md`, `silver/schema-drift.md`, `silver/incremental-with-deletes.md`, `decisions/source-has-no-delete-signal.md`, `gold/incremental-aggregate-recalc.md`, `semantic-model/incremental-period.md`. Write them or drop the links.

## Removed and consolidated

- `facts/incremental-load.md` → split 2026-09-06 into `facts/incremental-date-partition.md` and `facts/incremental-open-settled.md`
- `facts/partition-based-incremental-load.md`, `facts/watermark-based-load.md`, `facts/full-load.md` (old) → folded into the fact patterns above
- `force-update-modes.md` → restored as `cross-cutting/force-update.md`
- `surrogate-key-management.md` → in `gold/dimension-patterns/incremental-load.md`
- `dimension-rebuild-cascade.md`, `incremental-with-key-drift.md`, `incremental-aggregate-recalc.md`, `late-arriving-facts.md` → covered by the patterns above
- `INDEX-1.md` → merged into this file 2026-09-06
